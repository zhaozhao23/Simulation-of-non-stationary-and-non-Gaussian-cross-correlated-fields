The Matlab code of the method proposed in the paper:

Z. Zhao, Z. Lu, Y. Zhao, Simulating non-stationary and non-Gaussian cross-correlated fields using multivariate Karhunen–Loève expansion and L-momentsbased Hermite polynomial model, Mechnaical Systems and Signal Processing, 2024